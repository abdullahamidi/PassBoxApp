﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAPI.Repository
{
    public interface IPasswordRepo
    {
        void DeletePassword(int passwordId);
        IEnumerable<Password> GetPasswordsByUserId(int userId);
        public Password GetPasswordById(int passwordId);
        IEnumerable<Password> GetPasswords();
        void InsertPassword(Password password);
        void UpdatePassword(Password password);
        void Save();
    }
}
