﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAPI.Repository
{
    public class PasswordRepo : IPasswordRepo
    {
        private readonly DatabaseContext _dbContext;

        public PasswordRepo(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void DeletePassword(int passwordId)
        {
            var password = _dbContext.Passwords.Find(passwordId);
            _dbContext.Passwords.Remove(password);
            Save();
        }
        public Password GetPasswordById(int passwordId)
        {
            return _dbContext.Passwords.Find(passwordId);
        }

        public IEnumerable<Password> GetPasswordsByUserId(int userId)
        {
            return _dbContext.Passwords.Where(p=> p.UserId == userId);
        }

        public IEnumerable<Password> GetPasswords()
        {
            return _dbContext.Passwords.ToList();
        }

        public void InsertPassword(Password password)
        {
            _dbContext.Add(password);
            Save();
        }

        public void Save()
        {
            _dbContext.SaveChanges();
        }

        public void UpdatePassword(Password password)
        {
            _dbContext.Entry(password).State = EntityState.Modified;
            Save();
        }
    }
}
