﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserAPI;

namespace UserAPI.Repository
{
    public interface IUserRepo
    {
        void DeleteUser(int userId);
        User GetUserByID(int userId);
        User GetUser(string username);
        IEnumerable<User> GetUsers();
        void InsertUser(User user);
        void UpdateUser(User user);
        void Save();

        Task<User> Authenticate(string username, string password);
    }
}
