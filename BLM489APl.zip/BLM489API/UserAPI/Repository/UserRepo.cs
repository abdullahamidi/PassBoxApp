﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserAPI.Repository
{
    public class UserRepo : IUserRepo
    {
        private readonly DatabaseContext _dbContext;

        public UserRepo(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }
        public void DeleteUser(int userId)
        {
            var product = _dbContext.Users.Find(userId);
            _dbContext.Users.Remove(product);
            Save();
        }

        public User GetUserByID(int userId)
        {
            return _dbContext.Users.Find(userId);
        }

        public User GetUser(string username)
        {
            return _dbContext.Users.FirstOrDefault(a=> a.Username == username);
        }

        public IEnumerable<User> GetUsers()
        {
            return _dbContext.Users.ToList();
        }

        public void InsertUser(User user)
        {
            user.UserPassword = Encoder(user.UserPassword);
            _dbContext.Add(user);
            Save();
        }

        public void Save()
        {
            _dbContext.SaveChanges();
        }

        public void UpdateUser(User user)
        {
            user.UserPassword = Encoder(user.UserPassword);
            _dbContext.Entry(user).State = EntityState.Modified;
            Save();
        }
        public string Encoder(string password)
        {
            if (string.IsNullOrEmpty(password)) return "";
            var encodedPwd = Encoding.UTF8.GetBytes(password);
            return Convert.ToBase64String(encodedPwd);
        }

        public string Decoder(string password)
        {
            if (string.IsNullOrEmpty(password)) return "";
            var decodedPwdBytes = Convert.FromBase64String(password);
            return Encoding.UTF8.GetString(decodedPwdBytes);
        }

        public async Task<User> Authenticate(string username, string password)
        {
            string encodedPwd = Encoder(password);
            var user = await Task.Run(() => _dbContext.Users.SingleOrDefault(x => x.Username == username && x.UserPassword == encodedPwd));

            // return null if user not found
            if (user == null)
                return null;

            // authentication successful so return user details
            return user;
        }
    }
}
