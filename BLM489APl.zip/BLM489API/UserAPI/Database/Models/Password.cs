﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserAPI

{
    public class Password
    {
        public int PasswordID { get; set; }
        public string PasswordType { get; set; }
        public string UserPassword { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }

        //Tablo Bağlantıları Kurulacak
    }
}
