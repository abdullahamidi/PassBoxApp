﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserAPI;
using UserAPI.Repository;

namespace UserAPI.Controllers
{
    [Route("/api/[controller]")]
    [ApiController]
    public class PasswordController : Controller
    {
        public IPasswordRepo _pwdRepo;

        public PasswordController(IPasswordRepo pwdRepo)
        {
            _pwdRepo = pwdRepo;
        }

        // GET /password
        [HttpGet("{userId}")]
        public IEnumerable<Password> GetByUserId(int userId)
        {
            return _pwdRepo.GetPasswordsByUserId(userId);
        }
        // POST /password
        [HttpPost]
        public void Insert([FromBody] Password pwd)
        {
            _pwdRepo.InsertPassword(pwd);
        }

        // DELETE /password/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _pwdRepo.DeletePassword(id);
        }
    }
}
