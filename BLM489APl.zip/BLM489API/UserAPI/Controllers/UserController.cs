﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserAPI;
using UserAPI.Database.Models;
using UserAPI.Repository;

namespace UserAPI.Controllers
{
    [Authorize]
    [DisableCors]
    [Route("/api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        public IUserRepo _userRepo;

        public UserController(IUserRepo userRepo)
        {
            _userRepo = userRepo;
        }

        // GET api/user
        [HttpGet]
        public IEnumerable<User> Get()
        {
            return _userRepo.GetUsers();
        }
        
        [HttpPost("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody] AuthModel model)
        {
            var user = await _userRepo.Authenticate(model.Username, model.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(user);
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<User> GetById(int id)
        {
            return _userRepo.GetUserByID(id);
        }

        // POST api/values
        [HttpPost]
        public void Insert([FromBody] User user)
        {
            _userRepo.InsertUser(user);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _userRepo.DeleteUser(id);
        }
    }
}
